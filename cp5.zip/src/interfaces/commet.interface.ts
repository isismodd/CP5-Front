export interface Comment {
  name: string
  text: string
  id: number
}